import { Client } from '@notionhq/client';

const notion = new Client({ auth: process.env.ATHENA_NOTION_TOKEN });

export async function handleNotionCommand(commandText) {
  try {
    const subject = commandText.split('::')[1]?.trim(); // 🧠 FIXED
    if (!subject) throw new Error('Invalid Notion subject');

    const response = await notion.pages.create({
      parent: { database_id: process.env.ATHENA_NOTION_DB },
      properties: {
        Name: {
          title: [
            {
              text: {
                content: subject,
              },
            },
          ],
        },
      },
    });

    return response;
  } catch (error) {
    console.error('🧨 Notion Error:', error);
    throw error;
  }
}